# Tự đánh giá — Phạm Hoàng Minh · G10

## 1. Tự rà soát 4 cảnh

Đã rà soát toàn bộ ảnh trong bộ dữ liệu. Bốn cảnh dưới đây là các trường hợp tiêu biểu.

| Ảnh | Đối tượng | Loại lỗi | Ghi chú | Đã sửa? |
|---|---|---|---|---|
| S01 | child_seat — rear_right | missing | Ảnh RGB tối, khó nhận ra ghế trẻ em; tăng brightness mới quan sát được | Đã kiểm tra lại và gán khi đủ căn cứ |
| S03 | child_seat — rear_left; infant_seat — rear_middle | missing | Ảnh RGB tối, cần tăng brightness để nhận diện hai loại ghế | Đã kiểm tra lại và gán khi đủ căn cứ |
| D01 | face / face13 | occlusion | Tài xế quay mặt, không quan sát được đầy đủ vùng mặt và các điểm mốc | Không suy đoán điểm không xác định được; dùng cờ theo guideline |
| D02 | hand — right | occlusion | Tay phải bị che khuất, không thể quan sát đầy đủ | Chỉ gán phần nhìn thấy được theo guideline |

## 2. Lỗi mình lặp lại nhiều nhất hôm nay

**Lỗi:** Khó nhận diện và có nguy cơ bỏ sót đối tượng trong ảnh RGB tối.

**Vì sao mình mắc:** Độ sáng và độ tương phản của ảnh thấp khiến hình dạng ghế trẻ em và ghế trẻ sơ sinh khó quan sát.

**Lần sau tránh bằng cách:** Kiểm tra ảnh ở chế độ hiển thị phù hợp, điều chỉnh brightness/contrast trên CVAT khi cần. Sau đó đối chiếu với ảnh IR-sim cùng cảnh. Chỉ gán nhãn khi có đủ căn cứ, không suy đoán đối tượng bị khuất hoặc không rõ.

## 3. Ghi chú về review chéo và disagreement_log

Đã review trực tiếp cùng Phạm Vũ Tùng Dương (03319) trong quá trình thực hiện. Hai bạn cùng xem ảnh, trao đổi và đối chiếu các trường hợp cần lưu ý với GUIDE.md. Hai bạn thống nhất áp dụng guideline, không ghi nhận bất đồng cần phân xử hoặc sửa nhãn do bất đồng.

Không có hai bản export độc lập để chạy peer diff. Vì không phát sinh bất đồng nên disagreement_log.csv chỉ có hàng tiêu đề, không có dòng bất đồng giả.
