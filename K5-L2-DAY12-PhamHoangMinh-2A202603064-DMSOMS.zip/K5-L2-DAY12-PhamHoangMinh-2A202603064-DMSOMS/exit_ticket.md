# Exit ticket — Ngày 12

**Họ tên:** Phạm Hoàng Minh · **Mã:** G10

---

**Câu 1 · Chọn một.**

Đáp án: **B**

Lý do: Đèn LED cận hồng ngoại 940 nm giúp camera DMS thu được hình ảnh khuôn mặt tài xế ổn định cả ngày lẫn đêm mà không gây chói mắt.

**Câu 2 · Số, 2 chữ số thập phân.**

Số khung hình:
314 - 240 + 1 = 75 khung hình.

Thời gian:
75 / 30 = 2.50 giây.

Đáp án: **2.50 s**

**Câu 3 · Chọn tất cả đáp án đúng.**

Đáp án: **B, C, D**

- B đúng: Ảnh cabin ban đêm thường dùng hồng ngoại đen trắng, không đủ căn cứ để gán màu áo.
- C đúng: Camera OMS nhìn về phía sau xe nên bên trái ảnh là bên phải xe.
- D đúng: Vật trong cabin thường nhỏ, ở xa và có nhiều vật thể trong cùng một ảnh.
- A không chọn vì phát biểu tuyệt đối về việc không thể làm mờ mặt là không chính xác.
- E không chọn vì dữ liệu cabin vẫn cần guideline và QC riêng.
