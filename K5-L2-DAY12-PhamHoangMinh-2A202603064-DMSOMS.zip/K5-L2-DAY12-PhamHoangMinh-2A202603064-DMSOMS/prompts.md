# Khai báo dùng AI — Phạm Hoàng Minh

| # | Công cụ | Bạn hỏi gì (tóm tắt) | Bạn dùng kết quả thế nào | Bạn có kiểm lại không? Bằng gì? |
|---|---|---|---|---|
| 1 | ChatGPT | Hỏi cách thực hiện bài lab DMS/OMS, giải thích guideline, hỗ trợ xử lý lỗi và hoàn thiện các file bàn giao | Dùng hướng dẫn để thao tác trên CVAT, kiểm tra nhãn và soạn tài liệu; các quyết định gán nhãn dựa trên ảnh gốc và guideline | Có. Tự kiểm tra trên CVAT, đối chiếu GUIDE.md, chạy cabin_check.py. Không tải ảnh cabin hoặc ảnh tài xế lên AI |
