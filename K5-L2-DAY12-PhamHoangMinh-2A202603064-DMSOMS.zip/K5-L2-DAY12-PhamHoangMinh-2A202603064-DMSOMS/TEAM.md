# TEAM — Ngày 12

Mã bộ ảnh: **G10** · Hình thức: **Cá nhân, có review trực tiếp cùng bạn ghép**

| Họ tên | MSSV | Đã gán đủ 22 ảnh? | Review chéo với | Số dòng disagreement đã xử lý |
|---|---|---|---|---|
| Phạm Hoàng Minh | 2A202603064 | Có | Phạm Vũ Tùng Dương (03319) — review trực tiếp trong quá trình làm | 0 — không phát sinh bất đồng |

## Kết quả review chéo

- Minh và Dương cùng xem ảnh, trao đổi và đối chiếu các trường hợp cần lưu ý với `GUIDE.md` trong quá trình thực hiện.
- Hai bạn thống nhất áp dụng guideline; không ghi nhận bất đồng cần phân xử hoặc sửa nhãn do bất đồng.
- Không tạo peer diff riêng vì hai bạn review trực tiếp, không có hai bản export độc lập để so sánh.
- Không có `export_final_v2.zip` vì không phát sinh rework sau review chéo.

## Cá nhân

### Phạm Hoàng Minh — 2A202603064

- Phần mình làm: Gán nhãn bộ ảnh G10 gồm 22 ảnh chính; thực hiện kiểm tra chất lượng và làm thêm phần mở rộng S09–S10.
- Điều mình học được hôm nay: Cần đối chiếu RGB với IR-sim khi ảnh RGB tối; phân biệt đúng trái/phải theo góc nhìn của xe và không suy đoán đối tượng hoặc điểm mốc bị che khuất.
