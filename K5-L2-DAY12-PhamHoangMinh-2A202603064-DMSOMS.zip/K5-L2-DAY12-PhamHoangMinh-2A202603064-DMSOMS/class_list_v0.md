# Danh sách lớp v0 — Phạm Hoàng Minh · G10

Danh sách lớp và thuộc tính được xây dựng dựa trên GUIDE Cabin v1.0 và schema `labels_cabin_v1.json`.

## DMS

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng DMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | `person` | `seat=driver` | Xác định vị trí và vùng cơ thể tài xế | Có, tùy độ rõ |
| 2 | `face` | Bounding box khuôn mặt | Xác định vị trí khuôn mặt tài xế | Có, tùy góc mặt và ánh sáng |
| 3 | `face` — thuộc tính mắt trái/phải | `open / closed / unknown` | Phát hiện trạng thái mắt, hỗ trợ nhận biết dấu hiệu buồn ngủ; đây là thuộc tính của `face`, không phải label độc lập | Có, nhưng có thể bị kính hoặc phản xạ che |
| 4 | `glasses` | `unknown / none / clear / sun` | Nhận biết kính và hỗ trợ xử lý trường hợp mắt bị che | Có, nhưng kính có thể khó phân biệt trên NIR |
| 5 | `gaze_zone` | `road / mirror_l / mirror_r / mirror_c / cluster / center / lap / other` | Xác định hướng nhìn và phát hiện tài xế không tập trung nhìn đường | Có, tùy độ rõ của mắt và hướng đầu |
| 6 | `face13` | 13 điểm mặt; từng điểm có cờ `occluded / outside` | Xác định các điểm mốc khuôn mặt phục vụ phân tích tư thế và trạng thái mặt | Có, nếu mặt đủ rõ và rộng ít nhất 60 px |
| 7 | `hand` | `whose`, `side`, `on_wheel` | Theo dõi vị trí tay và tương tác với vô lăng | Có, tùy vùng tay có bị che |
| 8 | `phone` | `held / mounted / lap` | Phát hiện điện thoại và hành vi sử dụng điện thoại | Có, nếu thấy rõ hình dạng điện thoại |

## OMS

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng OMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | `person` | `seat=driver / front_passenger / rear_left / rear_middle / rear_right` | Xác định người và vị trí người ngồi trong xe | Có, tùy độ rõ |
| 2 | `face` | Bounding box khuôn mặt | Xác định vị trí khuôn mặt người ngồi | Có, tùy góc mặt và ánh sáng |
| 3 | `child_seat` | `occupied=no / unknown` | Nhận diện ghế trẻ em và ghi nhận trạng thái có/không thể xác định người ngồi theo schema | Có, dựa vào hình dạng |
| 4 | `infant_seat` | `facing=rear / front` | Nhận diện ghế em bé và hướng quay của ghế | Có, dựa vào hình dạng |
| 5 | `object` | `type=bag / box / cup / other` | Nhận diện đồ vật trong cabin và vị trí của chúng | Có thể nhận diện qua hình dạng, không dựa vào màu |
| 6 | `seat` (thuộc tính) | `driver / front_passenger / rear_left / rear_middle / rear_right` | Xác định vị trí ghế theo cấu trúc của xe để gắn người và vật thể đúng vị trí | Có thể xác định qua bố cục cabin |

*Lưu ý: `seat` là thuộc tính, không phải label độc lập. `face` trong OMS chỉ cần bounding box, không cần đầy đủ thuộc tính như DMS.*

## 2 câu hỏi leo thang

1. **Câu hỏi:** Khi ảnh RGB quá tối, không nhìn rõ vật thể ban đầu nhưng sau khi tăng brightness/contrast trên CVAT thì có thể quan sát được hình dạng, có được phép dựa vào hình ảnh sau khi điều chỉnh để gán nhãn không? Nếu vẫn không chắc loại vật thể thì nên chọn `other` hay không tạo box?

   **Khung ví dụ:** Một ảnh RGB trong quá trình gán nhãn OMS, không ghi lại mã khung cụ thể.

   **Bạn tạm gán thế nào và vì sao:** Tăng brightness/contrast chỉ để hỗ trợ quan sát, không chỉnh sửa ảnh gốc. Chỉ tạo box khi có đủ căn cứ nhận diện vật thể; không đoán khi hình ảnh vẫn chưa rõ.

2. **Câu hỏi:** Khi vật thể bị che khuất một phần, tiêu chí nào để quyết định có đủ bằng chứng tạo box `object`?

   **Khung ví dụ:** Các ảnh OMS S01–S08 có vật thể trong cabin.

   **Bạn tạm gán thế nào và vì sao:** Chỉ gán khi xác định được vật thể từ phần hình dạng nhìn thấy. Box ôm phần nhìn thấy được, không tự suy đoán phần bị che.
